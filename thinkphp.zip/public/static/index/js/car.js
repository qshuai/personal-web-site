/**
 * Created by Andy on 2017/1/19.
 */
window.onload = function () {

    //立即购买
    var buy = $('.buy');
    $.each(buy, function (i) {
        buy.eq(i).click(function () {
            $('form').eq(i).submit();
        })
    });


    //移除操作
    var del = $('.del');
    var row =$('.row');
    $.each(del, function (i) {
        del.eq(i).click(function () {
            $.ajax({
                type    : 'post',
                url     : '/Thinkphp/public/index/myshop/car',
                data    : {
                    'id'    : $(this).next().val()
                },
                success:function (response) {
                    if (response == true){
                        row.eq(i).remove();
                        alert('该商品已被移除！');
                    }else{
                        alert('操作失败！')
                    }
                }
            })
        })
    })

};