window.onload = function () {
    $('.para-dd').find('input:first').attr('checked', true);

    //商品价格初始化
    var itemObj = $('.item');
    var itemCheckedObj = $('.item:checked');
    var param = {};
    for(var i=0;i<itemCheckedObj.length;i++){
        param[i] = itemCheckedObj.eq(i).val();
    }
    $.ajax({
        type    : 'post',
        url     : "/Thinkphp/public/index/shop/goods",
        data    : {
            'action'    : 'price',
            'id'        : $('#id').val(),
            'param'     : param
        },
        success:function (response) {
            $('.price_int').text(response);
        }
    });

    //实时更新商品价格
    itemObj.click(function () {
        var itemCheckedObj = $('.item:checked');
        var param = {};
        for(var i=0;i<itemCheckedObj.length;i++){
            param[i] = itemCheckedObj.eq(i).val();
        }
        $.ajax({
            type    : 'post',
            url     : "/Thinkphp/public/index/shop/goods",
            data    : {
                'action'    : 'price',
                'id'        : $('#id').val(),
                'param'     : param
            },
            success:function (response) {
                $('.price_int').text(response);
            }
        })
    });


    //提交订单
    $('.shopping').click(function () {
        var config = {};
        var itemname = $('.itemname');
        for(var i=0;i<itemname.length;i++){
            var value = $('input[name=param'+(i+1)+']');
            for(var j=0;j<value.length;j++){
                if (value.eq(j).is(':checked')){
                    config[itemname.eq(i).text()] = value.eq(j).parent().text();
                }
            }
        }
        $.ajax({
            type    : 'post',
            url     : "/Thinkphp/public/index/shop/goods",
            data    : {
                'action' : 'config',
                'data'   : config
            },
            success:function (response) {
                if (response == 'no'){
                    alert('程序需要开启缓存！')
                }else{
                    $('input[name=num]').val($('#des_num_text').val());
                    $('input[name=price]').val($('.price_int').text());
                    $('form').eq(0).submit();
                }
            }
        });
    });

    //加入购物车
    $('.car').click(function () {
        var config = {};
        var itemname = $('.itemname');
        for(var i=0;i<itemname.length;i++){
            var value = $('input[name=param'+(i+1)+']');
            for(var j=0;j<value.length;j++){
                if (value.eq(j).is(':checked')){
                    config[itemname.eq(i).text()] = value.eq(j).parent().text();
                }
            }
        }

        $.ajax({
            type    : 'post',
            url     : '/Thinkphp/public/index/shop/car',
            data    : {
                'action'    : 'car',
                'data'      : config,
                'id'        : $('input[name=id]').val(),
                'price'     : $('.price_int').text(),
                'num'       : $('#des_num_text').val()
            },
            success:function (response) {
                if (response == true){
                    alert('加入购物车成功！');
                }else{
                    alert('未知原因，加入购物车失败！');
                }
            }
        })
    });

    //收藏商品
    var favobtn = $('.favobtn');
    favobtn.css('cursor', 'pointer');
    favobtn.click(function () {
        favobtn.find('span:first').removeClass('icon-unfavorite2').addClass('icon-favorite');
        $.ajax({
            type    : 'post',
            url     : '/Thinkphp/public/index/shop/goods',
            data    : {
                'action'    : 'favo',
                'data'      : $('#id').val()
            },
            success:function (response) {
                if (response == false){
                    alert('您已经收藏过了');
                }
            }
        })
    });


};
