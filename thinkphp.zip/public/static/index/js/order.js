window.onload = function () {
    //收货地址初始化
    var sit = $('input[name=site]');
    var thumbnail = $('.thumbnail');
    sit.val(thumbnail.eq(0).find('input').val());
    
    //选择收货地址
    for(var i=0;i<thumbnail.length;i++){
        thumbnail.eq(i).click(function () {
            for(var j=0;j<thumbnail.length;j++){
                thumbnail.eq(j).css('border','2px solid #DDDDDD');
            }
            $(this).css('border','2px solid #3f729b');
            sit.val($(this).find('input').val());
            $('.to').text('寄送地址：' + $(this).find('h4').text());
        })
    }
};