window.onload = function () {
    $('.item').eq(0).addClass('active');
}
