/**
 * Created by Andy on 2017/1/20.
 */
window.onload = function () {
    var dl = $('.dl');
    $.each(dl, function (i) {
        dl.eq(i).click(function () {
            $.ajax({
                type    : 'post',
                url     : '/Thinkphp/public/index/download/index',
                data    : {
                    'data'  : $(this).next().val()
                }
            })
        })

    })
};