window.onload = function () {
    var del = $('.delete');
    var subdelete = $('.subdelete');
    var auto = $('.auto');
    del.eq(0).click(function () {
        $.ajax({
            type    : 'post',
            url     : "/Thinkphp/public/index/myshop/site",
            data    : {
                'action'    : 'del',
                'id'        : $(this).next().val()
            },
            success:function (response) {
                if (response == 'yes'){
                    del.parentsUntil('.row').remove();
                }else{
                    alert('删除收货地址失败！');
                }
            }
        })
    });

    for(var i=0;i<subdelete.length;i++){
        subdelete.eq(i).click(function () {
            $.ajax({
                type    : 'post',
                url     : "/Thinkphp/public/index/myshop/site",
                data    : {
                    'action'    : 'del',
                    'id'        : $(this).prev().val()
                },
                success:function (response) {
                    if (response == 'yes'){
                        location.reload();
                    }else{
                        alert('删除收货地址失败！');
                    }
                }
            })
        })
    }

    for(var i=0;i<auto.length;i++){
        auto.eq(i).click(function () {
            $.ajax({
                type    : 'post',
                url     : "/Thinkphp/public/index/myshop/site",
                data    : {
                    'action'    : 'auto',
                    'id'        : $(this).next().val()
                },
                success:function (response) {
                    if (response == 'yes'){
                        location.reload();
                    }else{
                        alert('设置失败！');
                    }
                }
            })
        })
    }
};