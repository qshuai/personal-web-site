$(function () {
    //登出
    $('#logout').click(function () {
        $.ajax({
            type : "POST",
            url : "/Thinkphp/public/index.php/index/load/logout",
            data : {
                'action' : "logout"
            },
            success:function () {
                window.location.reload();
            }
        })
    });

    //验证码刷新
    $('#refresh').click(function () {
        $(this).attr('src','/Thinkphp/public/captcha.html?random='+Math.random());
    });

    //显示回复框
    var replyobj = $('.reply');
    var frameobg = $('.frame');
    $.each(replyobj,function (i) {
        replyobj.eq(i).click(function () {
            frameobg.eq(i).removeClass('hidden');
        })
    });

    //跟帖回复之后隐藏回复框 并Ajax提交
    var publish = $('.publish');
    var tocontent = $('.tocontent');
    var touserobj = $('.touser');
    $.each(publish,function (i) {
        publish.eq(i).click(function () {
            var content = '回复： '+touserobj.eq(i).text()+' '+tocontent.eq(i).val();
            var aid = $('.aid').val();
            var touser = $('.touserval').eq(i).val();
            var rid = $('.rid').eq(i).val();

            $.ajax({
                type : "POST",
                url : "/Thinkphp/public/index.php/index/reply/rartical",
                data : {
                    'content' : content,
                    'aid' : aid,
                    'rid' : rid,
                    'touser' : touser
                },
                success:function () {
                    window.location.reload();
                }
            });
            frameobg.eq(i).addClass('hidden');
        })
    });

    //让文档正文区域充满屏幕
    $('body').css('min-height', window.screen.availHeight-90);

});
