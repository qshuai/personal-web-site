/**
 * Created by Andy on 2017/1/20.
 */
window.onload = function () {
    var favo = $('.unfavo');
    var box  = $('.col-sm-6');
    $.each(favo, function (i) {
        favo.eq(i).click(function () {
            $.ajax({
                type    : 'post',
                url     : '/Thinkphp/public/index/myshop/favo',
                data    : {
                    'action'    : 'unfavo',
                    'data'      : $(this).next().val()
                },
                success:function (response) {
                    if (response == true){
                        box.eq(i).remove();
                    }
                }
            })
        })
    })
};