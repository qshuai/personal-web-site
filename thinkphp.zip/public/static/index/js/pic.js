//由于jqury在footer中加载 所以这里使用的是window.onload
window.onload=function () {
    //点击评论出现回复框
    $('#comment').click(function () {
            $('.reply').removeClass('hidden');
    });

    //点击发表，Ajax提交评论内容，并且回复框隐藏
    $('.send').click(function () {
        var pic = $('#pid').val();
        var username = $('#username').val();
        var content = $('#basic-url').val();
        $.ajax({
            type : "POST",
            url : "/Thinkphp/public/index.php/index/image/reply",
            data : {
                'pic'       : pic,
                'username'  : username,
                'content'   : content,
                'date'      : new Date().getTime()
            },
            success:function () {
                window.location.reload();
            }
        });
        $('.reply').addClass('hidden');
    });

    $('#like').click(function () {
        var pic = $('#pid').val();
        $.ajax({
            type : "GET",
            url  : "/Thinkphp/public/index.php/index/image/like",
            data : {
                'pid'   : pic
            },
            success:function (response) {
                if (response == true){
                    num = $('#like').find('span');
                    num.text(parseInt(num.text()) + 1);
                }
            }
            });
        });


    $('#hate').click(function () {
        var pic = $('#pid').val();
        $.ajax({
            type : "GET",
            url  : "/Thinkphp/public/index.php/index/image/hate",
            data : {
                'pid'   : pic
            },
            success:function (response) {
                if (response == true){
                    num = $('#hate').find('span');
                    num.text(parseInt(num.text()) + 1);
                }
            }
        });
    });


};
