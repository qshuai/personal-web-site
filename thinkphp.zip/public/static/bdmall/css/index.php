<?php
$file = file_get_contents('goodslist.css');
$file = str_replace('}',"}\r\n",$file);
$file = str_replace('}',"\r\n}",$file);
$file = str_replace('{',"{\r\n\t",$file);
$file = str_replace(";",";\r\n",$file);
file_put_contents('test.css',$file);