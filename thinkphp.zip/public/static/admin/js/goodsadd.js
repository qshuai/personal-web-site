window.onload = function(){
    //加载二级分类
    var num = $('.cate').length;
    for (var i=0;i<num;i++){
        $('.cate').eq(i).click(function(){
            $.ajax({
                type    : 'POST',
                url     : "/Thinkphp/public/admin/goods/goodsadd",
                data    : {
                    'action'       : 'getsubcate',
                    'cate'         : this.value
                },
                success:function (response) {
                    var html = '';
                    for (var j=0;j<response.length;j++){
                        html = html + '<label><input type="radio" name="subcate" class="sub" value="'+response[j]["subcate"]+'">'+response[j]["subcate"]+'</label>';
                    }
                    $('.subcate').html('<label class="col-sm-2 control-label">二级分类</label>');
                    $('.subcate').append(html);

                    //加载三级分类
                    var subnum = $('.sub').length;
                    for (var k=0;k<subnum;k++){
                        $('.sub').eq(k).click(function(){
                            $.ajax({
                                type    : 'POST',
                                url     : "/Thinkphp/public/admin/goods/goodsadd",
                                data    : {
                                    'action'       : 'getsubclass',
                                    'subcate'      : this.value
                                },
                                success:function (response){
                                    var content = '';
                                    for (var m=0;m<response.length;m++){
                                        content = content + '<label><input type="radio" name="subclass" class="subsub" value='+response[m]["id"]+'>'+response[m]["subclass"]+'</label>';
                                    }
                                    $('.subclass').html('<label class="col-sm-2 control-label">三级分类</label>');
                                    $('.subclass').append(content);

                                    //加载对应属性
                                    for(var n=0;n<$('.subsub').length;n++){
                                        $('.subsub').eq(n).click(function(){
                                            $.ajax({
                                                type    : 'POST',
                                                url     : "/Thinkphp/public/admin/goods/goodsadd",
                                                data    : {
                                                    'action'    : 'getattr',
                                                    'subclass'  : this.value
                                                },
                                                success:function(response){
                                                    var attr = '';
                                                    for (var q=0;q<response.length;q++){
                                                        attr = attr + '<label><input type="checkbox" name="attr" class="attribute" value='+response[q]["aname"]+'>'+response[q]["aname"]+'<input type="hidden" class="hid" value='+response[q]["subclass"]+'></label>';
                                                    }
                                                    $('.attr').html('<label class="col-sm-2 control-label">商品属性</label>');
                                                    $('.attr').append(attr);

                                                    //加载对应属性值
                                                    for(var p=0;p<$('.attribute').length;p++) {
                                                        $('.attribute').eq(p).click(function () {
                                                            $(this).attr('disabled','disable');
                                                            $.ajax({
                                                                type: 'POST',
                                                                url: "/Thinkphp/public/admin/goods/goodsadd",
                                                                data: {
                                                                    'action': 'getavalue',
                                                                    'aname': this.value,
                                                                    'subclass': $('.hid').val()
                                                                },
                                                                success: function (response) {
                                                                    var avalue = '';
                                                                    for (var s = 0; s < response.length; s++) {
                                                                        avalue = avalue + '<label><input type="hidden" value='+response[s]["id"]+'><input type="checkbox" name="avalue" class="attrvalue" value=' + response[s]["aname"] + '>' + response[s]["avalue"] + '</label>';
                                                                    }
                                                                    $('.avalue').append(avalue);
                                                                }
                                                            })
                                                        })
                                                    }
                                                }
                                            })
                                        })
                                    }
                                }
                            });
                        })
                    }
                }
            });
        })
    }

    $('body').on('click','.selbtn',function(){
        // for(var j=0;j<$('.attribute:checked').length;j++){
        //     for(var i=0;i<$('.attrvalue:checked').length;i++){
        //         if($('.attribute:checked').eq(j).val() == $('.attrvalue:checked').eq(i).val()){
        //             var row = '<tr> <td class="aname">'+$('.attribute:checked').eq(j).val()+'</td><td>'+$('.attrvalue:checked').eq(i).parent().text()+'</td><td><input type="text" name="stock[]"></td><td><input type="text" name="price[]"><input type="hidden" name="avalueid[]" value='+$('.attrvalue:checked').eq(i).prev().val()+'></td></tr>';
        //             $('#info').append(row);
        //         }
        //     }
        // }
        var data = {};
        for(var i=0;i<$('.attrvalue:checked').length;){
            var m=0;
            data[$('.attrvalue:checked').eq(i).val()]  = {};
            for(var j=i;j<$('.attrvalue:checked').length;j++){
                if ($('.attrvalue:checked').eq(j).val() == $('.attrvalue:checked').eq(i).val()){
                    data[$('.attrvalue:checked').eq(i).val()][$('.attrvalue:checked').eq(j).prev().val()]= $('.attrvalue:checked').eq(j).parent().text();
                    m++;
                }else{
                    break;
                }
            }
            i = i + m;
        }
        $.ajax({
            type : 'post',
            url  : "/Thinkphp/public/admin/goods/goodsadd",
            data : {
                'action'    : 'cal',
                'data'      : data

            },
            success:function (response) {
                $('#info').html(response);
            }
        });

        $('.selbtn').addClass('disabled');
    })

};
