window.onload = function () {
    $('#plus').click(function () {
        if ($('.copy').length <6){
            $('.copy').clone().appendTo('div.add');
        }else{
            alert('对不起，一次最多只能添加9张图片！');
        }
    })
}
