$(function () {
    //验证码刷新
    $('#refresh').click(function () {
        $(this).attr('src','/Thinkphp/public/captcha.html?random='+Math.random());
    });
});