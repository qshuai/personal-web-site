<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------

// 应用公共文件
function str_filter($str, $length){
    $str = strip_tags($str);
    $str = mb_substr($str, 0, $length);
    return $str;
}

//过滤用户输入的数据，便于数据库插入
function html_filter($str){
    return htmlspecialchars(addslashes($str));
}

//还原用户输入内容
function html_decode($str){
    return html_entity_decode(stripslashes($str));
}

//还原用户输入内容 并去掉标签
function html_strip($str){
    return strip_tags(stripslashes($str));
}

/**
 * @param $dir  目录路径
 * @return bool 参数是一个目录返回true，否则返回false
 */
function deldir($dir){
    if (is_dir($dir)) {
        $dh = opendir($dir);
        while ($file = readdir($dh)) {
            if ($file != '.' && $file != '..') {
                $fullPath = $dir . '/' . $file;
                if (!is_dir($fullPath)) {
                    @unlink($fullPath);
                } else {
                    $this->deldir($fullPath);
                }
            }
        }
        closedir($dh);
        return true;
    }else{
        return false;
    }
}

/**
 *  本函数用于修改和新增配置
 *  作用于当前模块下的config.php文件
 * @param $config   一维数组的配置文件
 * @param $all      表示是否对所有模块有效
 */
function configSet($config, $all = false){
    $file = $all ? (ROOT_PATH.'application/'.request()->module().'/config.php') : (ROOT_PATH.'application/'.request()->module().'/config.php');
    $content = file_get_contents($file);
    foreach($config as $key=>$item){
        if (preg_match("/{$key}/",$content)){
            $content = preg_replace("/({$key}'\s*\=\>\s*)'?.*?'?,/","\${1}'{$item}',",$content);
        }else{
            $content = substr($content,0,-2);
            $content .= "\r\n'".$key.'\' => \''.$item.'\',];';
        }
    }
    file_put_contents($file, $content);
}

/**
 * @param $value    数组元素值
 * @param $key      数组键值
 */
function category(&$value, $key){
    $value = ['category' => $value];
}

function subcate(&$value, $key, $userdata){
    $value = ['subcate' => $value, 'category' => $userdata];
}

function subclass(&$value, $key, $userdata){
    $value = ['subclass' => $value, 'category' => $userdata[0], 'subcate' => $userdata[1]];
}

//根据id自动生成链接
function linkcate(&$value, $key, $userdata){
	if ($key == 'link'){
		$value = "/subcatelist/".substr(md5($userdata),10,8);
	}
}

//根据id自动生成链接
function linkclass(&$value, $key, $userdata){
	if($key == 'link'){
		$value = "/subclaslist/".substr(md5($userdata),10,8);
	}
}

