<?php

//admin模块配置文件
return[
    //后台头部logo
    'logo'              => 'Scrap管理系统后台' ,

    //后台title
    'title'             => 'Scrap内容管理后台页面',

    //爬虫设置
    //爬虫第一条内容title
    'first'         => '如何快速分析三角桁架受力情况？',
    //爬虫网页总数
    'count'          => '100',
    //Ajax网址前段
    'forward'       => 'https://www.zhihu.com/node/ExploreAnswerListV2?params=%7B%22offset%22%3A',
    //Ajax网址后端
    'last'          => '%2C%22type%22%3A%22month%22%7D',
    //起始url地址
    'url'           => 'https://www.zhihu.com/explore#monthly-hot',

    //模板定义
    'template'          => [
        //开启统一布局
        'layout_on'     =>true,
        //设置统一布局入口文件
        'layout_name'   =>'layout',
    ]


];