<?php
namespace app\admin\controller;

class Sysset extends Base{
    public function sys(){

        return $this->fetch();
    }

    /**
     *  清除缓冲文件
     */
    public function clearCache(){
        if (deldir(ROOT_PATH.'runtime/cache')){
            $this->success('清除缓存成功！','admin/sysset/sys','',1);
        }else{
            $this->success('目录不存在！','admin/sysset/sys','',1);
        }
    }

    /**
     *  清除临时文件
     */
    public function clearTemp(){
        if (deldir(ROOT_PATH.'runtime/temp')){
            $this->success('清除临时文件成功！','admin/sysset/sys','',1);
        }else{
            $this->success('目录不存在！','admin/sysset/sys','',1);
        }
    }

}