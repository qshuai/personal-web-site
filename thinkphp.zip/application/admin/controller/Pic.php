<?php
namespace app\admin\controller;
use think\Db;
use app\admin\model\Picture;


class Pic extends Base
{
    public function upload()
    {
        if (request()->isPost()) {
            Db::startTrans();
            try {
                $img = request()->file('img');
                foreach ($img as $file) {
                    $info = $file->validate(['size'=>10000000,'ext'=>'jpg,jpeg,png,gif,tif'])->move(ROOT_PATH . 'upload/album');
                    if ($info) {
                        $picname = $info->getSavename();
                        $data = [
                            'cid' => input('cid'),
                            'aid' => input('aid'),
                            'picname' => $picname,
                            'date' => time()
                        ];
                        Db::name('pic')->insert($data);
                    } else {
                        return $file->getError();
                    }
                }
                Db::commit();
                echo "<script type='text/javascript'>alert('上传成功！');window.back();</script>";
            } catch (\Exception $e) {
                Db::rollback();
                $this->error('上传失败');
            }
        }
            $col = new Picture();
            $catelist = $col->name('cate')->field('id,catename')->select();
            $albumlist = $col->name('album')->field('id,cid,albumname')->order('cid')->select();
            $this->assign('catelist', $catelist);
            $this->assign('albumlist', $albumlist);
            return $this->fetch('upload');
    }

    public function piclist(){
        $piclist = Db::table('think_pic')
                        ->alias('p')
                        ->join('__CATE__ c','c.id = p.cid')
                        ->join('__ALBUM__ a','a.id = p.aid')
                        ->field('c.catename,a.albumname,p.id,p.picname,p.date,p.first')
                        ->order('p.cid,p.aid')
                        ->paginate(10);
        $this->assign('piclist',$piclist);
        return $this->fetch();
    }

    public function delete(){
        if (request()->isGet()){
            $id = request()->param('id');
            $pic = new Picture();
            $picname = $pic->name('pic')->where('id', $id)->value('picname');
            if (unlink(ROOT_PATH.'upload/album/'.$picname)){
                if ($pic->name('pic')->delete($id)){
                    return "<script>alert('图片删除成功！');history.back(-1);</script>";
                }else{
                    $this->error('图片数据库删除失败！');
                }
            }else{
                $this->error('图像文件删除失败！');
            }
        }
    }

    //首页展示
    public function first(){
        if (request()->isGet()){
            $id = request()->param('id');
            $album = Db::table('think_pic')->where('id',$id)->value('aid');
            $count = Db::table('think_pic')->where(['aid'=>$album, 'first'=>1])->count();
            $firstid = Db::table('think_pic')->where('first',1)->value('id');
            if ($count>=1){
                if ($firstid == $id){
                    if (Db::table('think_pic')->update(['first'=>0,'id'=>$id])){
                        return "<script>alert('取消首页展示成功');history.back()</script>";
                    }
                }else {
                    $this->error('对不起，您已经为当前相册设置过首页展示了！');
                }
            }else{
                $data = [
                    'first' => 1,
                    'id'    => $id
                ];
                if (Db::table('think_pic')->update($data)){
                    return "<script>alert('设置首页展示成功');history.back()</script>";
                }
            }
        }
    }
}