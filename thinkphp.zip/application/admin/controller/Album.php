<?php
namespace app\admin\controller;
use app\admin\controller\Base;
use app\admin\model\Picture;
use think\Loader;

class Album extends Base{
    //显示栏目列表
    public function albumlist(){
        $album = new Picture();
        $albumlist = $album ->name('album')->paginate(12);
        $this->assign('albumlist',$albumlist);
        return $this->fetch('albumlist');
    }

    //增加图像栏目
    public function addalbum(){
        if (request()->isPost()){
            $data = [
                'cid'       =>  input('cid'),
                'albumname' => input('albumname'),
                'abstract'  => input('abstract'),
                'username'  => cookie('username'),
                'date'      => time()
            ];
            $validate = Loader::validate('Album');
            if ($validate->scene('album')->check($data)){
                $album = new Picture();
                $album->name('album')
                    ->insert($data);
                $this->success('新增成功！','albumlist','',1);
            }else{
                $this->error($validate->getError());
            }
        }
        $album = new Picture();
        $res = $album->name('cate')->select();
        $this->assign('res',$res);
        return $this->fetch('addalbum');
    }

    //编辑栏目信息
    public function edit(){
        if (!input('id')){
            $this->error('未选择栏目id，拒绝访问！');
        }
        $album = new Picture();
        $editlist = $album->name('album')->where('id',input('id'))->find();
        $this->assign('editlist',$editlist);
        $res = $album->name('cate')->select();
        $this->assign('res',$res);
        return $this->fetch('edit');
    }

    //处理编辑栏目的信息
    public function update(){
        if(request()->isPost()){
            $data = [
                'id'        => input('id'),
                'cid'       => input('cid'),
                'albumname' => input('albumname'),
                'abstract'  => input('abstract'),
            ];
            $validate = Loader::validate('Album');
            if ($validate->scene('album')->check($data)){
                $album = new Picture();
                $album->name('album')->update($data);
                $this->success('编辑成功！', 'albumlist','',1);
            }else{
                $this->error($validate->getError());
            }
        }
    }

    //删除栏目
    public function delete(){
        if (input('id')){
            $album = new Picture();
            $album->name('album')->delete(input('id'));
            $this->success('删除成功！','albumlist','',1);
        }
    }
}