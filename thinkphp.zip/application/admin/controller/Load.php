<?php
namespace app\admin\controller;
use think\Controller;
use think\Cookie;

class Load extends Controller
{
    public function load(){
        if (request()->isPost()){
            $data = [
                'username'  => input('username'),
                'password'  => md5(input('password')),
                'level'     => ['neq', 1]
            ];
            if ($info = \think\Db::table('think_user')->where($data)->find()){
                Cookie::set('username',$info['username']);
                Cookie::set('unicode',$info['unicode']);
                $this->success('欢迎管理员'.$data['username'].'登录！','admin/index/index');
            }else{
                $this->error('用户名或密码错误！');
            }
        }
        return $this->fetch();
    }

    //退出登录
    public function logout(){
        Cookie::delete('username');
        Cookie::delete('unicode');
        $this->redirect('admin/load/load');
    }
}
