<?php
namespace app\admin\controller;
use app\admin\controller\Base;
use app\admin\model\Picture;
use think\Loader;

class Cate extends Base{
    //显示栏目列表
    public function catelist(){
        $album = new Picture();
        $catelist = $album ->name('cate')->paginate(12);
        $this->assign('catelist',$catelist);
        return $this->fetch('catelist');
    }

    //增加图像栏目
    public function addCate(){
        if (request()->isPost()){
            $data = [
                'catename'  => input('catename'),
                'abstract'  => input('abstract'),
                'username'  => cookie('username'),
                'date'      => time()
            ];
            $validate = Loader::validate('Album');
            if ($validate->scene('cate')->check($data)){
                $album = new Picture();
                $album->name('cate')
                    ->insert($data);
                $this->success('新增成功！','catelist','',1);
            }else{
                $this->error($validate->getError());
            }
        }
        return $this->fetch('addcate');
    }

    //编辑栏目信息
    public function edit(){
        if (!input('id')){
            $this->error('未选择栏目id，拒绝访问！');
        }
        $album = new Picture();
        $editlist = $album->name('cate')->where('id',input('id'))->find();
        $this->assign('editlist',$editlist);
        return $this->fetch('edit');
    }

    //处理编辑栏目的信息
    public function update(){
        if(request()->isPost()){
            $data = [
                'id'        => input('id'),
                'catename'  => input('catename'),
                'abstract'  => input('abstract'),
            ];
            $validate = Loader::validate('Album');
            if ($validate->scene('cate')->check($data)){
                $album = new Picture();
                $album->name('cate')->update($data);
                $this->success('编辑成功！', 'catelist','',1);
            }else{
                $this->error($validate->getError());
            }
        }
    }

    //删除栏目
    public function delete(){
        if (input('id')){
            $album = new Picture();
            $album->name('cate')->delete(input('id'));
            $this->success('删除成功！','catelist','',1);
        }
    }
}