<?php
namespace app\admin\controller;
use app\admin\model\User;
use think\Controller;

class Base extends Controller{
    //向页面输出标准Ueditor
    protected $editor = '<textarea name="content" id="editor"></textarea><script type="text/javascript" src="http://localhost/PHP/CMV/public/static/ueditor/ueditor.config.js"></script><script type="text/javascript" src="http://localhost/PHP/CMV/public/static/ueditor/ueditor.all.js"></script><script type="text/javascript">var ue = UE.getEditor("editor");</script>';
    //向页面输出mini版Ueditor
    protected $editormini = '<textarea name="content" id="editormini" required></textarea><script type="text/javascript" src="http://localhost/PHP/CMV/public/static/ueditor/ueditor.configmini.js"></script><script type="text/javascript" src="http://localhost/PHP/CMV/public/static/ueditor/ueditor.all.js"></script><script type="text/javascript">var ue = UE.getEditor("editormini");</script>';

    protected function _initialize()
    {
        $username = cookie('username') ? cookie('username') : false;
        $unicode = cookie('unicode') ? cookie('unicode') : false;
        if (!$username || !$unicode){
            $this->error('请先登录！','admin/load/load','',1);
        }
        $condition = [
            'level'     => ['neq', 1],
            'username'  => $username,
        ];
        $checkadmin = db('user')->where($condition)->value('unicode');
        if ($checkadmin != $unicode){
            $this->error('非法操作！');
        }

        $user = new User();
        $this->assign('info',$user->where('username',cookie('username'))->cache('info')->find());
    }

}