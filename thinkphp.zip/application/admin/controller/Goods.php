<?php
namespace app\admin\controller;
use app\admin\model\Goodsall;
use app\admin\model\Product;

class Goods extends Base{
    private $obj;

    protected $beforeActionList = [
        'instance'
    ];

	//在所有方法执行前，实例化模型类Goodsall
    protected function instance(){
        return $this->obj = new Goodsall();
    }

    //删除 所有的删除操作都在这里，跳转不太好解决
    public function delete(){
        $id = request()->param('id');
        if ($id){
            if ($this->obj->name('goods')->delete($id)){
                $this->success('删除成功！','admin/goods/category','',1);
            }
        }else{
            $this->error('操作错误！');
        }
    }
	//------------------------------------------------------------------------------------------------------------
	//自动链接
	public function autolink(){
		$condsubcate = [
            'category'  => ['neq','0'],
            'subcate'   => ['neq','0'],
            'subclass'  => '0',
			'link'		=> '0'
        ];
		$condsubclass = [
            'category'  => ['neq','0'],
            'subcate'   => ['neq','0'],
            'subclass'  => ['neq','0'],
			'link'		=> '0'
        ];
		$goods = new Goodsall();
		$subcate = db('goods')->where($condsubcate)->field('id,link')->select();
		if ($subcate){
			foreach($subcate as $value){
				array_walk($value, 'linkcate', $value['id']);
				$catelink[] = $value;
			}
			$goods->saveAll($catelink);
		}
		
		$subclass = db('goods')->where($condsubclass)->field('id,link')->select();
		if ($subclass){
			foreach($subclass as $value){
				array_walk($value, 'linkclass', $value['id']);
				$classlink[] = $value;
			}
			$goods->saveAll($classlink);
		}
		$this->success('自动链接成功建立！','admin/goods/category');
	}
    //---------------------------------------------------------------------------------------------------------------
    //显示
    public function category(){
        $condition = [
            'category'  => ['neq','0'],
            'subcate'   => '0',
            'subclass'  => '0'
        ];
        $result = $this->obj->name('goods')->where($condition)->paginate(15);
        $this->assign('catelist', $result);
        return $this->fetch();
    }

    //新增
    public function cateadd(){
        if (request()->isPost()){
            if (strpos(input('catename'),' ')){
                $data = explode(' ',input('catename'));
                array_walk($data,'category');
                if ($this->obj->name('goods')->insertAll($data)){
                    $this->success('新增成功！','admin/goods/category');
                }
            }else{
                $data = [
                    'category'  => input('catename'),
                ];
                if ($this->obj->name('goods')->insert($data)){
                    $this->success('新增成功！','admin/goods/category');
                }
            }
        }
        return $this->fetch();
    }

    //编辑
    public function cateedit(){
        $id = request()->param('id');
        if (request()->isPost()){
            $data = [
                'id'        => $id,
                'category'  => input('catename')
            ];
            if ($this->obj->name('goods')->update($data)){
                $this->success('修改成功！','admin/goods/category','',1);
            }
        }
        if ($id){
            $result = $this->obj->name('goods')->where('id',$id)->find();
            $this->assign('cate',$result);
            return $this->fetch();
        }else{
            $this->error('操作错误！');
        }
    }

    //----------------------------------------------------------------------------------------------------------------
    public function subcate(){
        $condition = [
            'category'  => ['neq','0'],
            'subcate'   => ['neq','0'],
            'subclass'  => '0'
        ];
        $result = $this->obj->name('goods')->where($condition)->paginate(15);
        $this->assign('subcate', $result);
        return $this->fetch();
    }

    public function subcateadd(){
        if (request()->isPost()){
            if (strpos(input('subcate'),' ')){
                $data = explode(' ',input('subcate'));
                array_walk($data,'subcate', input('category'));
                if ($this->obj->name('goods')->insertAll($data)){
                    $this->success('新增成功！','admin/goods/subcate');
                }
            }else{
                $data = [
                    'category'  => input('category'),
                    'subcate'   => input('subcate')
                ];
                if ($this->obj->name('goods')->insert($data)){
                    $this->success('新增成功！','admin/goods/subcate');
                }
            }
        }
        $condition = [
            'category'  => ['neq','0'],
            'subcate'   => '0',
            'subclass'  => '0'
        ];
        $result = $this->obj->name('goods')->where($condition)->select();
        $this->assign('category', $result);
        return $this->fetch();
    }

    //编辑
    public function subcateedit(){
        $id = request()->param('id');
        if (request()->isPost()){
            $data = [
                'id'        => $id,
                'subcate'  => input('subcate')
            ];
            if ($this->obj->name('goods')->update($data)){
                $this->success('修改成功！','admin/goods/subcate','',1);
            }
        }
        if ($id){
            $result = $this->obj->name('goods')->where('id',$id)->find();
            $this->assign('subcate',$result);
            return $this->fetch();
        }else{
            $this->error('操作错误！');
        }
    }


    //---------------------------------------------------------------------------------------------------------------

    public function subclass(){
        $condition = [
            'category'  => ['neq','0'],
            'subcate'   => ['neq','0'],
            'subclass'  => ['neq','0']
        ];
        $result = $this->obj->name('goods')->where($condition)->paginate(15);
        $this->assign('subclass', $result);
        return $this->fetch();
    }

    public function subclassadd(){
        if (request()->isPost()){
            if (strpos(input('subclass'),' ')){
                $data = explode(' ',input('subclass'));
                array_walk($data,'subclass', [input('category'),input('subcate')]);
                if ($this->obj->name('goods')->insertAll($data)){
                    $this->success('新增成功！','admin/goods/subclass');
                }
            }else{
                $data = [
                    'category'  => input('category'),
                    'subcate'   => input('subcate'),
                    'subclass'  => input('subclass')
                ];
                if ($this->obj->name('goods')->insert($data)){
                    $this->success('新增成功！','admin/goods/subclass');
                }
            }
        }
        $condition = [
            'category'  => ['neq','0'],
            'subcate'   => '0',
            'subclass'  => '0'
        ];
        $result = $this->obj->name('goods')->where($condition)->select();
        $this->assign('category', $result);

        $con = [
            'category'  => ['neq','0'],
            'subcate'   => ['neq','0'],
            'subclass'  => '0'
        ];
        $res = $this->obj->name('goods')->where($con)->select();
        $this->assign('subcate', $res);
        return $this->fetch();
    }

    public function subclassedit(){
        $id = request()->param('id');
        if (request()->isPost()){
            $data = [
                'id'        => $id,
                'subclass'  => input('subclass')
            ];
            if ($this->obj->name('goods')->update($data)){
                $this->success('修改成功！','admin/goods/subclass','',1);
            }
        }
        if ($id){
            $result = $this->obj->name('goods')->where('id',$id)->find();
            $this->assign('subclass',$result);
            return $this->fetch();
        }else{
            $this->error('操作错误！');
        }
    }

    //---------------------------------------------------------------------------------------------------------------

    public function goods(){
        return $this->fetch();
    }

    public function goodsadd(){
		//Ajax请求二级分类
		if (request()->param('action') == 'getsubcate'){
			$cate = request()->param('cate');
			$condition = [
				'category'  => $cate,
				'subcate'   => ['neq','0'],
				'subclass'  => '0'
			];
			$subcate = $this->obj->where($condition)->field('subcate')->select();
			return $subcate;
		}

		//Ajax请求三级分类
		if (request()->param('action') == 'getsubclass'){
			$subcate = request()->param('subcate');
			$condition = [
				'subcate'	=> $subcate,
				'subclass'  => ['neq','0']
			];
			$subclass = $this->obj->where($condition)->field('id,subclass')->select();
			return $subclass;
		}

		//请求对应属性
		if (request()->param('action') == 'getattr'){
			$attr = db('attr')->where('subclass',request()->param('subclass'))->group('aname')->select();
			return $attr;
		}

		//请求对应属性值
		if(request()->param('action') == 'getavalue'){
			cookie('subclass', request()->param('subclass'));
			$avalue = db('attr')->where(['aname'=>request()->param('aname'),'subclass'=>request()->param('subclass')])->select();
			return $avalue;
		}

		//用于sku表格布局
        if (request()->param('action') == 'cal'){
		    $data = request()->param('data/a');

		    //缓冲这个二维数组，为了数据库插入
		    cache('data',$data,3600);

            $len = count($data);

            $table = '<table><tr>';
            foreach($data as $key => $value){
                $sublen[] = count($value);
                $table .='<th>'.$key.'</th>';
            }
            $table .= '<th>库存</th><th>价格</th></tr>';

            $subdata = array_values($data);

            //现在商品最多有3个属性，如果多于3个，其他的无法显示
            if ($len == 1){
                foreach($subdata[0] as $key1 => $value1){
                    $table .= '<tr><td>'.$value1.'</td><td><input type="text" name="stock[]"></td><td><input type="text" name="price[]"><input type="hidden" name="avalueid[]" value='.$key1.'></td></tr>';
                }
            }

            if ($len == 2){
                foreach($subdata[0] as $key1 => $value1){
                    foreach($subdata[1] as $key2 => $value2){
                        $table .= '<tr><td>'.$value1.'</td><td>'.$value2.'</td><td><input type="text" name="stock[]"></td><td><input type="text" name="price[]"><input type="hidden" name="avalueid[]" value='.$key1.'|'.$key2.'></td></tr>';
                    }
                }
            }

            if ($len == 3){
                foreach($subdata[0] as $key1 => $value1){
                    foreach($subdata[1] as $key2 => $value2){
                        foreach($subdata[2] as $key3 => $value3){
                            $table .= '<tr><td>'.$value1.'</td><td>'.$value2.'</td><td>'.$value3.'</td><td><input type="text" name="stock[]"></td><td><input type="text" name="price[]"><input type="hidden" name="avalueid[]" value='.$key1.'|'.$key2.'|'.$key3.'></td></tr>';
                        }
                    }
                }
            }

            $table .= '</table>';
            return $table;
        }

        //这个post放在最后，用于表单提交
		if(request()->isPost()){
		    //添加商品基本信息到think_product表
		    $data['subclass']   = input('subclass');
		    $data['title']      = input('title');
		    $data['subtitle']   = input('subtitle');
		    $data['franking']   = input('franking');
		    $data['pic']        = count(request()->file('pic'));
		    $data['content']    = input('content');
		    $product = new Product();
		    $id = $product->insertGetId($data);

		    if (cache('data')){
                db('param')->insert(['param'=>serialize(cache('data')), 'pid'=>$id]);
            }else{
		        $product->delete($id);
		        $this->error('缓存失效！');
            }

		    //将商品图像保存在相应目录，并规定命名规则，从1开始命名
		    $file = request()->file('pic');
		    foreach($file as $key=>$pic){
		        $info = $pic->move(ROOT_PATH.'upload/goods/'.$id, $key+1);
		        if (!$info){
		            echo $info->getError();
                }
            }

            //添加商品sku信息到think_sku表
            $len = count(request()->param('avalueid/a'));
            for ($i=0;$i<$len;$i++){
                $sku[$i]['pid']    = $id;
                $sku[$i]['avalue'] = request()->param('avalueid/a')[$i];
                $sku[$i]['price']  = request()->param('price/a')[$i];
                $sku[$i]['stock']  = request()->param('stock/a')[$i];
            }
            db('sku')->insertAll($sku);
            $this->success('新增商品成功！','admin/goods/goods');
        }

		//分配一级分类
		$condition = [
			'category'  => ['neq','0'],
			'subcate'   => '0',
		];
		$cate = $this->obj->name('goods')->where($condition)->field('category')->select();
		$this->assign('cate', $cate);
		return $this->fetch();
    }

    public function goodsedit(){
        return $this->fetch();
    }

}