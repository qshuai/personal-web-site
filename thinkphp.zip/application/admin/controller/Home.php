<?php
namespace app\admin\controller;
use app\admin\controller\Base;

class Home extends Base{
    //轮播图
    public function carousel(){
        $carousel = db('carousel')->select();
        $this->assign('carousel', $carousel);
        return $this->fetch();
    }

    //轮播图设置
    public function carset(){
        if (request()->isPost()){
            if (input('num')){
                $num = input('num');
                $this->assign('num',$num);
                return $this->fetch();
            }else{
                $result = request()->param()['link'];
                $data = [];
                $i = 0;
                foreach($result as $key=>$value){
                    if ($key %2 == 0){
                        $data[$i]['location'] = $value;
                    }else{
                        $data[$i]['link'] = $value;
                        $data[$i]['date'] = time();
                        $i++;
                    }
                }
                if (db('carousel')->insertAll($data)){
                    $this->success('轮播图设置成功！','admin/home/carousel');
                }
            }
        }
        $this->assign('num', 1);
        return $this->fetch();
    }

    //轮播图修改
    public function edit(){
        if (request()->isPost()){
            $data = [
                'id'        => input('id'),
                'location'  => input('location'),
                'link'      => input('link'),
                'date'      => time()
            ];
            if (db('carousel')->update($data)){
                $this->success('修改成功！','admin/home/carousel','',1);
            }else{
                $this->error('未知原因，修改失败！');
            }
        }

        if (request()->param('id')){
            $this->assign('carousel',db('carousel')->find(request()->param('id')));
            return $this->fetch();
        }
    }

    //轮播图删除
    public function delete(){
        if (request()->param('id')){
            if (db('carousel')->delete(request()->param('id'))){
                $this->success('此轮播图删除成功！','admin/home/carousel','',1);
            }
        }
    }
}