<?php
namespace app\admin\controller;
use app\admin\controller\Base;
use app\admin\model\Artical;

class Crawler extends Base{
    public function setall(){
        new Base();
        if (request()->isPost()){
            $data = [
                'first'     => input('first'),
                'url'       => input('url'),
                'forward'   => input('forward'),
                'last'      => input('last'),
                'count'     => input('count')
            ];
            configSet($data);
        }
        return $this->fetch();
    }

    /**
     * @param $firstTitle   当前时间第一个当日热点的title
     * @param int $count    设置爬虫网页个数
     * @param string $url   选择抓取的页面
     */
    public function index(){
        $firstTitle = config('first');
        $count = config('count');
        $url = config('url');
        $ch = curl_init();
        $timeout = 20;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_CAINFO, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
        $html = curl_exec($ch);
        curl_close($ch);
        $stripPattern = '/<h2><a.*?>.*?<\/a><\/h2>/s';
        $html = preg_replace($stripPattern, '', $html, 1);
        $contentPattern = '/<h2><a.*?>(.*?)<\/a><\/h2>.*?<textarea hidden class=\"content\">(.*?)<\/textarea>.*?<p class=\"visible\-expanded\"><a itemprop=\"url\" class=\"answer\-date\-link meta\-item\" data\-tooltip=\"s\$t\$(.*?)\".*?>(.*?)<\/a><\/p>/s';
        preg_match_all($contentPattern, $html, $content, PREG_SET_ORDER);
        $content[0][1] = $firstTitle;

        //如果要获取ajax加载的数据需要ajax请求的地址
        $forward = config('forward');
        $last = config('last');
        for ($i=0;$i<$count;$i=$i+5){
            $till = array();
            $ch = curl_init();
            $timeout = config('tomeout');
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_CAINFO, false);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
            $urlfollow = $forward.''.$i.''.$last;
            curl_setopt($ch, CURLOPT_URL, $urlfollow);
            $html = curl_exec($ch);
            curl_close($ch);
            $contentPattern = '/<h2><a.*?>(.*?)<\/a><\/h2>.*?<textarea hidden class=\"content\">(.*?)<\/textarea>.*?<p class=\"visible\-expanded\"><a itemprop=\"url\" class=\"answer\-date\-link meta\-item\" data\-tooltip=\"s\$t\$(.*?)\".*?>(.*?)<\/a><\/p>/s';
            preg_match_all($contentPattern, $html, $till, PREG_SET_ORDER);
            $content = array_merge($content,$till);
        }
        $yesterday = date('Y-m-d',time()-86400);
        $today = date('Y-m-d',time());
        cache('yesterday', $yesterday, 86400);
        cache('today', $today, 86400);
        $count = count($content);
        for ($i=0;$i<$count;$i++){
            $content[$i][3] = $this->publish_time($content[$i][3]);
            $content[$i][4] = $this->edit_time($content[$i][4]);
        }

        foreach($content as $value) {
            $key = ['','title','content','pubtime','edittime'];
            $value = array_combine($key,$value);
            $value['date'] = time();
            array_shift($value);
            $artical = Artical::name('artical');
            if ($artical->insert($value)){
                $this->success('爬虫成功','admin/crawler/setall');
            }
        }
    }

    /**
     * @param $string       传入的包含时间 或 时间和日期的字符串
     * @return mixed|string 修改成完整的data或datatime格式的字符串
     */
    private function publish_time($string){
        $string = str_replace('发布于 ', '', $string);
        $string =str_replace('昨天', cache('yesterday'), $string);
        $string = str_replace('今天', cache('today'), $string);
        if(strlen($string)<6){
            $string = cache('today').' '.$string;
        }
        return $string;
    }

    /**
     * @param $string       传入的包含时间 或 时间和日期的字符串
     * @return mixed|string 修改成完整的data或datatime格式的字符串
     */
    private function edit_time($string){
        $string = str_replace('编辑于 ', '', $string);
        $string =str_replace('昨天', cache('yesterday'), $string);
        $string = str_replace('今天', cache('today'), $string);
        if(strlen($string)<6){
            $string = cache('today').' '.$string;
        }
        return $string;
    }

    /**
     * @return string 返回爬虫结果，并输出
     */
    public function getContent(){
        $actical = Artical::table('think_artical');
        $content = $actical->find();
        return html_entity_decode($content['date']);
    }


    //初始化操作
    public function _initialize(){

    }
}