<?php
namespace app\admin\controller;
use think\Controller;
use app\admin\model\User;

class Member extends Base{
    public function userlist(){
        $user = new User();
        $res = $user->field('password,unicode',true)->order('level')->select();
        $this->assign('res',$res);
        return $this->fetch();
    }

    //判断用户级别
    /**
     * @param $id       当前操作的用户id（操作对象）
     */
    public function isAllow($id){
        $user = new User();
        $userlevel = $user->where('username',cookie('username'))->value('level');
        $opelevel = $user->where('id',$id)->value('level');
        if (!((int)$userlevel < (int)$opelevel)){
            $this->error('您没有权限进行此操作！');
        }
    }

    //升级
    public function levelup(){
        $id = request()->param('id');
        if ($id){
            $this->isAllow($id);
            $user = new User();
            $user->where('id',$id)->setDec('level');
            $this->success('成功升级！','admin/member/userlist','',1);
        }
    }

    //降级
    public function leveldown(){
        $id = request()->param('id');
        if ($id){
            $this->isAllow($id);
            $user = new User();
            $user->where('id',$id)->setInc('level');
            $this->success('成功降级！','admin/member/userlist','',1);
        }
    }

    //删除
    public function delete(){
        $id = request()->param('id');
        if ($id){
            $this->isAllow($id);
            db('user')->delete($id);
            $this->success('成功删除会员！','admin/member/userlist','',1);
        }
    }
}