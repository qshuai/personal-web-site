<?php
namespace app\admin\controller;

class Source extends Base{
    //上传资源
    public function upload(){
        if (request()->isPost()){
            $data['title']    = input('title');
            $data['abstract'] = input('abstract');
            $data['uid'] = db('user')->where('username', cookie('username'))->value('id');
            $file = request()->file('file');
            $image = request()->file('image');
            $name = time();
            $resource = $file->move(ROOT_PATH.''.DS.'upload/download', $name);
            $img = $image->move(ROOT_PATH.''.DS.'upload/download', $name);
            if($resource && $img){
                $data['link'] = $name;
                $data['fext'] = $resource->getExtension();
                $data['imgext'] = $img->getExtension();
                if (db('source')->insert($data)) {
                    $this->success('资源上传成功','admin/source/ls');
                }
            }
        }
        return $this->fetch();
    }

    //资源列别
    public function ls(){
        $this->assign('source', db('source')->paginate(8));
        return $this->fetch();
    }
}