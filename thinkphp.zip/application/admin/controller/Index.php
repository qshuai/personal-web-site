<?php
namespace app\admin\controller;

class Index extends Base
{
    public function index()
    {
        //会员情况
        $total = db('user')->count('id');
        $superAdmin = db('user')->where('level','-1')->count();
        $admin = db('user')->where('level','0')->count();
        $member = $total - $superAdmin -$admin;
        $this->assign('total', $total);
        $this->assign('superAdmin',$superAdmin);
        $this->assign('admin',$admin);
        $this->assign('member',$member);

        //文章情况
        $this->assign('artical', db('artical')->count());

        //评论
        $this->assign('rartical', db('rartical')->count());
        $this->assign('rpic', db('rpic')->count());

        //图片
        $this->assign('cate', db('cate')->count());
        $this->assign('album', db('album')->count());
        $this->assign('pic', db('pic')->count());
        return $this->fetch();
    }

}
