<?php
namespace app\admin\model;

class Picture extends Base{
    protected function getDateAttr($value){
        return date('Y-m-d H:i:s',$value);
    }

    protected function getCidAttr($value){
        $cate = db('cate')->field('id,catename')->select();
        foreach($cate as $res){
            if ($value == $res['id']){
                return $res['catename'];
            }
        }
    }

    protected function getAidAttr($value){
        $album = db('album')->field('id,albumname')->select();
        foreach($album as $res){
            if ($value == $res['id']){
                return $res['albumname'];
            }
        }
    }
}