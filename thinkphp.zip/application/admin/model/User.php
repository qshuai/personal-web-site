<?php
namespace app\admin\model;
use think\Model;

class User extends Model{
    protected function getDateAttr($value){
        return date('Y-m-d H:i:s',$value);
    }

    //当取用户id的时候自动转化为用户名
    protected function getLevelAttr($value){
        $level = [
            '-1'    => '超级管理员',
            '0'     => '管理员',
            '1'     => '普通会员'
        ];
        return $level[$value];
    }
}