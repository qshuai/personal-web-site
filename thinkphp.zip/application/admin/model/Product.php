<?php
namespace app\admin\model;

class Product extends Base{
    protected $table = 'think_product';

    protected $createTime = 'date';
    protected $updateTime = false;
}