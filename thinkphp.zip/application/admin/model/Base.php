<?php
namespace app\admin\model;
use think\Model;

class Base extends Model{
    protected $createTime = 'date';

}