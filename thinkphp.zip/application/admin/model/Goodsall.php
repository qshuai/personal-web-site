<?php
namespace app\admin\model;

class Goodsall extends Base{
	protected $table = 'think_goods';
	
	protected $createTime = 'date';
	protected $updateTime = false;
}