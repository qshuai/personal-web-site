<?php
namespace app\admin\validate;
use think\Validate;

class Album extends Validate{
    protected $rule = [
        'catename'      => 'require|length:2,15',
        'albumname'     => 'require|length:3,15',
        'cid'           => 'require',
        ];

    protected $message = [
        'catename.require'  => '栏目名称为必填项',
        'catename.length'   => '栏目名称不能少于2位，不能多于15位',
        'albumname.require' => '相册名称为必填项',
        'albumname.length'  => '相册名称不能少于3位，不能多于15位',
        'cid.require'       => '所属栏目不能为空！',
    ];

    //定义场景
    protected $scene = [
        'cate'      => 'catename',
        'album'     => ['albumname','cid'],
    ];
}