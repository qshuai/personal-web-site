<?php
namespace app\index\model;
use think\Model;

class User extends Model{
    protected function initialize(){
        parent::initialize();
    }

    protected function getLevelAttr($value){
        $status = [1=>'普通会员', 0=>'管理员'];
        return $status[$value];
    }
}