<?php
namespace app\index\model;
use think\Model;

class Goods extends Model{

	//url地址自动补全
	public function getLinkAttr($value){
		return request()->root(true).'/index/shop/mall'.$value;
	}
}