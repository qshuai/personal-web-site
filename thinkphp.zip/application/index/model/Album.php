<?php
namespace app\index\model;
use think\Model;

class Album extends Model{
//    public function pic(){
//        return $this->hasMany('Pic','aid');
//    }
}