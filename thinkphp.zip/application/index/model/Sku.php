<?php
namespace app\index\model;
use think\Model;

class Sku extends Model{
    protected function initialize(){
        parent::initialize();
    }
}

