<?php
namespace app\index\model;
use think\Model;

class Favo extends Model{
    public function setUidAttr($value){
        return db('mem')->where('username',$value)->value('id');
    }

    public function getUidAttr($value){
        return db('mem')->where('id',$value)->value('username');
    }

    public function setPicAttr($value){

    }
}