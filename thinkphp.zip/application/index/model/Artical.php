<?php
namespace app\index\model;
use think\Model;

class Artical extends Model{

    protected function initialize(){
        parent::initialize();
    }

    //当获取爬虫时间时，将该字段时间戳字符串转化为标准的datetime格式
    public function getDateAttr($value){
        //return date('Y-m-d H:i:s',$value);
    }

    public function getContentAttr($value){
        $prehtml = html_entity_decode($value);
        return preg_replace('/<img.*?\/>/s','',$prehtml);
    }

    public function getArtical(){
        $artical = Artical::table('think_artical');
        return $collection = $artical ->field('date',true)
            ->order('id DESC')
            ->cache(true)
            ->paginate(15);
    }


}