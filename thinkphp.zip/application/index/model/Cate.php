<?php
namespace app\index\model;
use think\Model;

class Cate extends Model{
    public function album(){
        return $this->hasMany('Album','cid');
    }

//    public function pic(){
//        $this->hasMany('Pic','cid');
//    }
}