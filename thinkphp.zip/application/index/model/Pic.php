<?php
namespace app\index\model;
use think\Model;

class Pic extends Model{
    public function setUidAttr($value){
        return db('mem')->where('username',$value)->value('id');
    }
}