<?php
namespace app\index\model;
use think\Model;

class Rartical extends Model{
    public function getContentAttr($value){
        return html_strip(html_entity_decode($value));
    }
}