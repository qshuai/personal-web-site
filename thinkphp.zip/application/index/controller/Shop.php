<?php
namespace app\index\controller;
use app\common\controller\Base;
use app\index\model\Goods;
use app\index\model\Sku;

class Shop extends Base{
	private $conCategory = [
			'category'  => ['neq','0'],
			'subcate'   => '0',
			'subclass'  => '0'
			];
	private $conSubcate = [
			'category'  => ['neq','0'],
			'subcate'   => ['neq','0'],
			'subclass'  => '0'
			];
	private $conSubclass = [
			'category'  => ['neq','0'],
			'subcate'   => ['neq','0'],
			'subclass'  => ['neq','0']
			];
	//+-------------------------------------------------------------------------
    public function index(){
		$goods = new Goods();
        $this->assign('category', $goods->where($this->conCategory)->cache(true)->select());
        $this->assign('subcate', $goods->where($this->conSubcate)->cache(true)->select());
        $this->assign('subclass', $goods->where($this->conSubclass)->cache(true)->select());
        return $this->fetch();
    }

    public function goods(){
        //实时更新价格
        if(request()->param('action') == 'price'){
            $sku = new Sku();
            $data = $sku->where('pid', input('id'))->select();
            foreach($data as $param){
                if (explode('|', $param['avalue']) == input('param/a')){
                    return $param['price'];
                }
            }
        }

        if(request()->param('action') == 'config'){
            if (cache('config',serialize(input('data/a')))){
                return 'yes';
            }else{
                return 'no';
            }
        }

        //收藏商品
        if (request()->param('action') == 'favo'){
            $data['uid']    = db('user')->where('username', cookie('username'))->value('id');
            $data['pid']    = input('data');
            if (db('favogoods')->where(['uid'=>$data['uid'],'pid'=>$data['pid']])->find()){
                return false;
            }else{
                db('favogoods')->insert($data);
                return true;
            }
        }

        //初始化页面
        if ($id = request()->param('id')){
            $this->assign('goodsinfo',$goods = db('product')->where('id', $id)->find());
            $this->assign('nav', db('goods')->where('id', $goods['subclass'])->find());
            $param = db('param')->where('pid', $id)->find();
            $this->assign('param', unserialize($param['param']));
            $is_favo =db('favogoods')->where('pid',input('id'))
                ->where('uid', db('user')->where('username', cookie('username'))->value('id'))
                ->find();
            $favo = $is_favo?true:false;
            $this->assign('favo', $favo);
            return $this->fetch();
        }else{
            $this->error('访问错误！','index/shop/index');
        }
    }

	public function mall(){
		if ($param = request()->param('subcatelist')){
			$goods = new Goods();

			//导航位置
			$nav = $goods->where('link','like','%'.$param)->field('category, subcate, link')->find();
			$this->assign('nav', $nav);

			//获取当前二级分类
			$subcate = $goods->where($this->conSubcate)->where('category', $nav['category'])->field('subcate,link')->select();
			$this->assign('subcate',$subcate);

			//获取当前三级分类
			$subclass = $goods->where($this->conSubclass)->where('subcate', $nav['subcate'])->field('subclass,link')->select();
			$this->assign('subclass',$subclass);

			//获取商品信息
            $goods = db('product')->select();
            $this->assign('goods', $goods);
            //return dump($goods);
			return $this->fetch('subcate');
		}

		if ($param = request()->param('subclaslist')){
			$goods = new Goods();
			//导航位置
			$nav = $goods->where('link','like','%'.$param)->order('id DESC')->field('category, subcate, subclass, link')->find();
			$this->assign('nav', $nav);

			//获取当前二级分类
			$subcate = $goods->where($this->conSubcate)->where('category', $nav['category'])->field('subcate,link')->select();
			$this->assign('subcate',$subcate);

			//获取当前三级分类
			$subclass = $goods->where($this->conSubclass)->where('subcate', $nav['subcate'])->field('subclass,link')->select();
			$this->assign('subclass',$subclass);
			return $this->fetch('subclass');
		}
	}

	//提交订单
    public function order(){
        //判断是否登录
        $this->isLoad();

	    if (request()->isPost()){
	        $this->assign('config', unserialize(cache('config')));
	        $time = date('Ymd', time()).''.substr(time(),rand(0,6),5);
	        $identifier = $time.''.rand(1000, 9999);
	        $this->assign('identifier', $identifier);

	        //分配收货地址变量
            $site = db('site')->where('uid', $uid = db('user')->where('username', cookie('username'))->value('id'))
                ->field('date', true)
                ->order('auto', 'DESC')
                ->select();
            $this->assign('uid', $uid);
            $this->assign('site', $site);
	        return $this->fetch();
        }else{
            $this->error('无效访问！');
        }
    }

    //支付页面
    public function pay(){
        //判断是否登录
        $this->isLoad();
        if (request()->param('id')){
            $order = db('order')->where('id', input('id'))->find();
            $this->assign('identifier', $order['identifier']);
            $this->assign('money', $order['money']);
            return $this->fetch();
        }

        if (request()->isPost()){
            $data['identifier'] = input('identifier');
            $data['uid']        = input('uid');
            $data['money']      = input('money');
            $data['site']       = input('site');
            $data['msg']        = input('msg');
            $data['pid']        = input('pid');
            $data['param']      = cache('config');

            //提交订单
            if (!db('order')->where('identifier', $data['identifier'])->find()){
                db('order')->insert($data);
            }
            $this->assign('identifier', $data['identifier']);
            $this->assign('money', $data['money']);
            return $this->fetch();
        }else{
            $this->error('非法操作');
        }
    }

    //购物车
    public function car(){
        $this->isLoad();

        //加入购物车操作
        if (input('action') == 'car'){
            $data['uid']    = db('user')->where('username', cookie('username'))->value('id');
            $data['pid']    = input('id');
            $data['config'] = serialize(input('data/a'));
            $data['price']  = input('price');
            $data['num']    = input('num');
            if(db('car')->insert($data)){
                return true;
            }else{
                return false;
            }
        }else{
            $this->error('错误访问！');
        }
    }
}