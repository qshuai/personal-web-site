<?php
namespace app\index\controller;
use app\common\controller\Base;
use think\Loader;

class Myshop extends Base{
    //收货地址页面初始化
    public function site(){
        //判断是否登录
        $this->isLoad();

        //ajax删除收货地址
        if (request()->param('action') == 'del'){
            if (db('site')->delete(input('id'))){
                return 'yes';
            }else{
                return 'no';
            }
        }

        //ajax修改默认收货地址
        if (input('action') == 'auto'){
            $uid = db('user')->where('username', cookie('username'))->value('id');
            db('site')->where('uid', $uid)
                ->where('auto', '1')
                ->update(['auto'=>'0']);
            if (db('site')->update(['id'=>input('id'),'auto'=>'1'])){
                return 'yes';
            }else{
                return 'no';
            }
        }

        //页面初始化
        $site = db('site')->where('uid', db('user')
            ->where('username', cookie('username'))->value('id'))
            ->field('date', true)
            ->order('auto', 'DESC')
            ->select();
        $this->assign('site', $site);
        return $this->fetch();
    }

    //新增收货地址
    public function siteadd(){
        //判断是否登录
        $this->isLoad();

        if (request()->isPost()){
            $data['name']   = input('user');
            $data['tel']    = input('tel');
            $data['site']   = input('site');
            $data['uid']    = db('user')->where('username', cookie('username'))->value('id');

            //默认收货地址判断
            if ((input('auto') == 'on')){
                db('site')->where('uid', $data['uid'])->where('auto', '1')->update(['auto'=>'0']);
                $data['auto'] = '1';
            }else{
                $data['auto'] = '0';
            }

            $validate = Loader::validate('Site');
            $validate->scene('siteadd');
            if (!$validate->check($data)){
                return $validate->getError();
            }
            if (db('site')->insert($data)){
                $this->success('新增收货地址成功！','index/myshop/site','',1);
            }else {
                $this->error('数据库写入失败，请重新操作！');
            }
        }
        return $this->fetch();
    }

    //购物车
    public function car(){
        //移除商品
        if (request()->isPost()){
            if (db('car')->delete(input('id'))){
                return true;
            }else{
                return false;
            }
        }

        //页面初始化
        $car = db('car')
            ->where('uid', db('user')->where('username', cookie('username'))->value('id'))
            ->alias('c')
            ->join('__PRODUCT__ p','p.id = c.pid')
            ->field('c.id, c.pid, c.price, c.num, c.date, c.config, c.date, p.title, p.franking')
            ->select();
        $this->assign('car', $car);
        return $this->fetch();
    }

    //订单
    public function order(){
        $this->isLoad();
        $order = db('order')->where('uid', db('user')->where('username', cookie('username'))->value('id'))
            ->alias('o')
            ->join('__PRODUCT__ p','o.pid = p.id')
            ->field('o.id, o.param, o.identifier, o.money, o.msg, o.status, p.title')
            ->select();
        $this->assign('order', $order);
        return $this->fetch();
    }

    //收藏夹
    public function favo(){
        //删除收藏
        if (request()->param('action') == 'unfavo'){
            if (db('favogoods')->delete(input('data'))){
                return true;
            }else{
                return false;
            }
        }

        $favo = db('favogoods')
            ->where('uid', db('user')->where('username', cookie('username'))->value('id'))
            ->alias('f')
            ->join('__PRODUCT__ p', 'p.id = f.pid')
            ->field('f.date, f.id, f.pid, p.title, p.subtitle')
            ->select();
        $this->assign('favo', $favo);
        return $this->fetch();
    }
}