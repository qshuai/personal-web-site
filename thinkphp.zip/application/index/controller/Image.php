<?php
namespace app\index\controller;
use app\admin\model\Picture;
use app\common\controller\Base;
use app\index\model\Cate;
use app\index\model\Album;
use app\index\model\Pic;
use app\index\model\Favo;

class Image extends Base{
    public function album(){
        $image = new Cate();
        $alb = new Album();
        $cate = $image->name('cate')->field('id,catename')->select();
        $album = $alb->name('album')->field('id,cid,albumname,abstract')->select();
        $pic = \think\Db::table('think_pic')->where('first',1)->select();
        $this->assign('cate',$cate);
        $this->assign('album',$album );
        $this->assign('pic',$pic);
        return $this->fetch();
    }

    public function piclist(){
        $id = request()->param('aid');
        $pic = new Pic();
        $res = $pic->where('aid',$id)->field('id,picname')->select();
        $this->assign('res',$res);
        return $this->fetch('piclist');
    }

    public function pic(){
        $id = request()->param('pid');
        $picname = str_replace('-','/',request()->param('picname'));
        $picname = substr($picname,0,-5);
        $this->assign('id',$id);
        $this->assign('picname',$picname);
        $likepic = \think\Db::table('think_likepic')->where('pic',$id)->count();
        $this->assign('likepic',$likepic);
        $hatepic = \think\Db::table('think_hatepic')->where('pic',$id)->count();
        $this->assign('hatepic',$hatepic);
        $reply = \think\Db::table('think_rpic')->where('pic',$id)->select();
        $this->assign('reply',$reply);
        $replynum = \think\Db::table('think_rpic')->where('pic',$id)->count();
        $this->assign('replynum',$replynum);
        return $this->fetch('pic');
    }

    public function like(){
        $this->isLoad();
        if (request()->param('pid')){
            $uid = db('user')->where('username',cookie('username'))->value('id');
            $data = [
                'pic'   => request()->param('pid'),
                'uid'   => $uid,
                'date'  => time()
            ];
            $res = db('likepic')->where('pic',$data['pic'])->field('uid')->select();
            foreach($res as $v){
                if ($v['uid'] == $uid){
                    return false;
                }
            }

            if (db('likepic')->insert($data)){
                return true;
            }
        }
    }

    public function hate(){
        $this->isLoad();
        if (request()->param('pid')){
            $uid = db('user')->where('username',cookie('username'))->value('id');
            $data = [
                'pic'   => request()->param('pid'),
                'uid'   => $uid,
                'date'  => time()
            ];
            $res = db('hatepic')->where('pic',$data['pic'])->field('uid')->select();
            foreach($res as $v){
                if ($v['uid'] == $uid){
                    return false;
                }
            }
            if (db('hatepic')->insert($data)){
                return true;
            }
        }
    }

    //收藏图片和相册
    public function favorite(){
        $this->isLoad();
        $favo = new Favo();
        $uid = db('user')->where('username',cookie('username'))->value('id');
        //收藏图片
        if (request()->param('pid')){
            $data = [
                'pic'   => request()->param('pid'),
                'uid'   => $uid,
                'date'  => time()
            ];
            $res = db('favo')->where('pic',$data['pic'])->field('uid')->select();
            foreach($res as $v){
                if ($v['uid'] == $uid){
                    $this->error('您已经收藏了此图片，请勿重复收藏！');
                }
            }

            if ($favo->insert($data)){
                return "<script type='text/javascript'>alert('图片收藏成功！');history.back();</script>";
            }
        }

        //收藏相册
        if (request()->param('aid')){
            $data = [
                'album'   => request()->param('aid'),
                'uid'   => $uid,
                'date'  => time()
            ];
            $res = db('favo')->where('album',$data['album'])->field('uid')->select();
            foreach($res as $v){
                if ($v['uid'] == $uid){
                    $this->error('您已经收藏了此相册，请勿重复收藏！');
                }
            }

            if ($favo->insert($data)){
                return "<script type='text/javascript'>alert('相册收藏成功！');history.back();</script>";
            }
        }
    }

    //回复功能
    public function reply(){
        $this->isLoad();
        if (!cookie('username')){
            $this->error('请先登录！','index/load/load','',1);
        }
        if (request()->isPost()){
            db('rpic')->insert(request()->param());
        }
    }
}