<?php
namespace app\index\controller;
use think\Controller;

class Download extends Controller{
    public function index(){
        if (request()->isPost()){
            if (db('source')->where('id', input('data'))->setInc('dlnum')){
                return true;
            }else{
                return false;
            }
        }

        $this->assign('source', db('source')->order('dlnum','DESC')->cache(true)->select());
        return $this->fetch();
    }

    public function info(){
        if (input('id')){
            $this->assign('info', db('source')->find(input('id')));
            return $this->fetch();
        }else{
            $this->error('访问错误','index/download/index');
        }
    }

    public function download(){

    }
}