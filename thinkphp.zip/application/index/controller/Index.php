<?php
namespace app\index\controller;
use app\index\model\Artical;
use app\common\controller\Base;


class Index extends Base{

    //用于主页显示
    public function index()
    {
        $artical = new Artical();
        $result = $artical->getArtical();
        cache('data',$result,6000);
        $this->assign('artical',$result);
        $this->assign('carousel',db('carousel')->limit(config('carousel'))->select());
        return $this->fetch();
    }


    //初始化函数，自动执行
    public function _initialize()
    {

    }

    public function artical(){
        $id = request()->param('id');
        if (!$id){
            $this->error('请求错误');
        }
        //这里只是暂时解决，依赖于index方法的缓冲时间
        foreach(cache('data') as $one){
            if ($one->id == $id){
                $this->assign('artical',$one);
                break;
            }
        }
        $this->assign('qrcode',$this->qrcode);
        $this->assign('editor',$this->editor);
        $this->assign('component',$this->component);

        //获取回复信息
        $reply = new Reply();
        $rlist = $reply->readReply($id);
        $this->assign('rlist',$rlist);
        return $this->fetch('artical');
    }

    public function search(){
        $this->inputVal();
        $keywords = request()->param('content');
        $list = preg_split('/\s+/',$keywords);
        $count = count($list);
        $artical = new Artical();
        $result = $artical->getArtical();
        $j = 0;
        $detail = array();
        foreach($result as $info){
            for($i=0;$i<$count;$i++){
                if (strstr($info->title,$list[0])){
                    $detail[$j]['id'] = $info->id;
                    $detail[$j]['title'] = $info->title;
                    $detail[$j]['content'] = str_filter($info->content,200);
                    $detail[$j]['pubtime'] = $info->pubtime;
                    break 1;
                }
            }
            $j++;
        }
        $this->assign('seacher_list', $detail);
        return $this->fetch('search');
    }

    //当URL访问该控制器时，如果遇到方法不存在的情况，会指定执行_empty()方法
    public function _empty(){
        return $this->error('页面不存在，请注意URL地址的正确性！');
    }
}

