<?php
namespace app\index\controller;
use app\common\controller\Base;
use app\index\model\Rartical;

class Reply extends Base{

    public function rartical(){
        //没有登录不能回复
        $this->isLoad();

        //验证码验证
        //$this->qrcodeVal();

        $request = request()->param();
        if ($request['rid']){
            $data['rid'] = $request['rid'];
        }else{
            $data['rid'] = 0;
        }

        if($request['touser']){
            $data['touser'] = $request['touser'];
        }else{
            $data['touser'] = '';
        }

        $data['user']       = cookie('username');
        $data['aid']        = $request['aid'];
        $data['content']    = html_filter($request['content']);
        $object = new Rartical();
        if ($object->insert($data)){
            return $this->success('回复成功');
        }

    }

    public function readReply($id){
        $raritcal = new Rartical();
        return $raritcal->where('aid',$id)->order('rid,id')->select();
    }
}