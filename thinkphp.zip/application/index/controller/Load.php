<?php
namespace app\index\controller;
use app\common\controller\Base;
use app\index\model\User;
use think\Cookie;

class Load extends Base{
    //登录功能
    public function load(){

        //判断如果已经登陆，则返回
        if(Cookie::has('username')){
            $this->error('请勿重复登陆！');
        }

        if (request()->post()){
            //验证验证码
            //$this->qrcodeVal();

            $data['username'] = request()->post('username');
            $data['password'] = md5(request()->post('password'));
            $user = User::table('think_user');
            $result = $user->where($data)->field('unicode')->find();
            if($result){
                if (request()->post('save')){
                    Cookie::set('username',$data['username'],3600);
                    Cookie::set('unicode',$result['unicode'],3600);
                }else{
                    Cookie::set('username',$data['username']);
                    Cookie::set('unicode',$result['unicode']);
                }
                $this->redirect('index/index/index');
            }else{
                $this->error('用户名或密码错误');
            }
        }

        //将验证码html输出到网页
        $this->assign('qrcode',$this->qrcode);
        return $this->fetch('load');
    }

    //退出登录
    public function logout(){
        if(request()->post('action') == 'logout'){
            Cookie::delete('username');
            Cookie::delete('unicode');
            return 'ok';
        }
    }
}