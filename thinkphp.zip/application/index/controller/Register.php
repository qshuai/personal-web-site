<?php
namespace app\index\controller;
use think\Cookie;
use think\Loader;
use think\Request;
use app\index\model\User;
use app\common\controller\Base;

class Register extends Base{

    //注册功能
    public function register(){
        //判断如果已经登陆，则返回
        if(Cookie::has('username')){
            return $this->error('请勿重复登陆！');
        }

        if (request()->isPost()){
            $request = Request::instance();

            //验证验证码
            //$this->qrcodeVal();

            //获取表单post数据
            $data = [
                'username'      => $request->post('username'),
                'password'      => $request->post('password'),
                'repassword'    => $request->post('repassword'),
                'email'         => $request->post('email'),
            ];

            //验证
            $validate = Loader::validate('User');
            $validate->scene('register');
            if(!$validate->check($data)){
                return $validate->getError();
            }else{
                $user = User::table('think_user');
                $username = $user->field('id')->where('username',$data['username'])->find();
                if ($username){
                    $this->error('此用户名已被注册！');
                }else{
                    $data['date'] = time();
                    $data['password'] = md5($data['password']);
                    $data['unicode'] = md5($data['username'].'think');
                    $user->field('username,password,email,unicode,date')->insert($data);
                }
                return $this->success('注册成功！','\index\load\load');
            }
        }

        //将验证码html输出到网页
        $this->assign('qrcode',$this->qrcode);
        return $this->fetch('register');
    }
}