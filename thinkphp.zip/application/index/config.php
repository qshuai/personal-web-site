<?php
/**
 *  index模块配置文件
 */

return[
    //网站title
    'title'         => 'Scrap内容管理',

    //模板定义
    'template'        => [
        //开启统一布局
        'layout_on'    =>true,
        //设置统一布局入口文件
        'layout_name'  =>'layout',
    ],

    'root'  => 'tihuan',

'ceshi' => 'success',];