<?php
namespace app\index\validate;
use think\Validate;

class Site extends Validate{
    protected $rule = [
        'tel'   => ['regex'=>'/^139|155|136|187|189|151[\d]{8}$/'],
    ];

    protected $message =[
        'tel.regex'     => '电话号码格式不正确！',
    ];

    protected $scene =[
        'siteadd'
    ];
}