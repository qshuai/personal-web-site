<?php
namespace app\index\validate;
use think\Validate;

class User extends Validate{
    //指定验证规则
    protected $rule = [
        'username'      => 'require|length:4,20|unique:mem',
        'password'  => 'require|min:6|confirm:repassword',
        'email'     => ['regex'=>'/^[0-9a-zA-Z][\w]{3,20}@[\w]{2,7}\.(com|cn)$/', 'require'],
    ];

    //指定验证失败信息
    protected $message =[
        'username.require'      => '用户名为必填项',
        'username.length'       => '用户名长度不能少于4位且不能大于20位',   //不起作用
        'username.unique'       => '用户名已存在',
        'password.require'      => '密码为必填项',
        'password.min'          => '密码长度不能少于6为',
        'password.confirm'      => '两次输入密码不一致',        //不起作用
        'email.regex'           => '邮箱格式不正确',           //不起作用
        'email.require'         => '邮箱不能为空',
    ];

    protected $scene =[
        'register',
    ];
}