<?php
namespace app\common\controller;
use think\Controller;
use think\Cookie;
use think\Request;

class Base extends Controller{
    //向页面输出验证码
    protected $qrcode = '<div class="form-group"><label for="qrcode" class="col-sm-2 control-label">验证码</label><div class="col-sm-10"><input type="text" name="qrcode" class="form-control" id="qrcode" placeholder="验证码"></div></div><div class="col-md-2 col-md-push-2"><img src="/Thinkphp/public/captcha.html" alt="captcha" id="refresh"/></div>';
    //向页面输出标准Ueditor
    protected $editor = '<textarea name="content" id="editor"></textarea><script type="text/javascript" src="/Thinkphp/public/static/ueditor/ueditor.config.js"></script><script type="text/javascript" src="/Thinkphp/public/static/ueditor/ueditor.all.js"></script><script type="text/javascript">var ue = UE.getEditor("editor");</script>';
    //向页面输出mini版Ueditor
    protected $editormini = '<textarea name="content" id="editormini" required></textarea><script type="text/javascript" src="/public/static/ueditor/ueditor.configmini.js"></script><script type="text/javascript" src="/public/static/ueditor/ueditor.all.js"></script><script type="text/javascript">var ue = UE.getEditor("editormini");</script>';
    //向页面输出刷新和回到头部组件
    protected $component = '<div class="btn-group" role="group" id="component"><a href=""><span class="btn glyphicon glyphicon-refresh pull-right"></span></a><br><a href="#top"><span class="btn glyphicon glyphicon-open pull-right"></span></a></div>';



    //验证码验证
    protected function qrcodeVal(){
        if(!captcha_check(request()->post('qrcode'))){
            $this->error('验证码输入错误！');
        };
    }

    //验证输入 不能为空
    protected function inputVal(){
        if (preg_match('/^\s*$/', request()->param('content'))){
            $this->error('内容输入不能为空！');
        };
    }

    //如果用户没有登录，不能进行相关操作
    function isLoad(){
        if (!cookie('username')){
            $this->error('请先登录！','index/load/load');
        }
    }
}